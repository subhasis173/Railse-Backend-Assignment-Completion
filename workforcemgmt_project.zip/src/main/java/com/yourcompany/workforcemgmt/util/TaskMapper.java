package com.yourcompany.workforcemgmt.util;

import com.yourcompany.workforcemgmt.dto.TaskDto;
import com.yourcompany.workforcemgmt.model.Task;

public class TaskMapper {
    public static TaskDto toDto(Task task) {
        TaskDto dto = new TaskDto();
        dto.setId(task.getId());
        dto.setTitle(task.getTitle());
        dto.setAssigneeId(task.getAssigneeId());
        dto.setStatus(task.getStatus());
        dto.setStartDate(task.getStartDate());
        dto.setPriority(task.getPriority());
        dto.setComments(task.getComments());
        dto.setHistory(task.getHistory());
        return dto;
    }
}
