package com.yourcompany.workforcemgmt.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Task {
    private Long id;
    private String title;
    private Long assigneeId;
    private TaskStatus status;
    private LocalDate startDate;
    private LocalDate endDate;
    private TaskPriority priority;
    private List<String> comments = new ArrayList<>();
    private List<String> history = new ArrayList<>();

    public Task(Long id, String title, Long assigneeId, TaskStatus status, LocalDate startDate, LocalDate endDate, TaskPriority priority) {
        this();
        this.id = id;
        this.title = title;
        this.assigneeId = assigneeId;
        this.status = status;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priority = priority;
    }

    public void addHistory(String event) {
        history.add(LocalDate.now() + ": " + event);
    }
}
