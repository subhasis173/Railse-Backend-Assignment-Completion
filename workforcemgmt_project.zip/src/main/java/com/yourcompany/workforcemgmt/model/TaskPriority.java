package com.yourcompany.workforcemgmt.model;

public enum TaskPriority {
    HIGH, MEDIUM, LOW
}
