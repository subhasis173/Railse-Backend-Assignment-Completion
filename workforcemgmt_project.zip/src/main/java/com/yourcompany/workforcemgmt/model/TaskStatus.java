package com.yourcompany.workforcemgmt.model;

public enum TaskStatus {
    OPEN, COMPLETED, CANCELLED
}
