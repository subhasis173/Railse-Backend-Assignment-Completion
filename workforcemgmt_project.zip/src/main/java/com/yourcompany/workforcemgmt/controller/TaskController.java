package com.yourcompany.workforcemgmt.controller;

import com.yourcompany.workforcemgmt.dto.*;
import com.yourcompany.workforcemgmt.model.TaskPriority;
import com.yourcompany.workforcemgmt.service.TaskService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public TaskDto createTask(@RequestBody CreateTaskRequest request) {
        return taskService.createTask(request);
    }

    @PostMapping("/assign-by-ref")
    public TaskDto reassignTask(@RequestParam Long taskId, @RequestParam Long newAssigneeId) {
        return taskService.reassignTask(taskId, newAssigneeId);
    }

    @GetMapping
    public List<TaskDto> getTasks(@RequestParam String start, @RequestParam String end) {
        return taskService.getTasksBetween(LocalDate.parse(start), LocalDate.parse(end));
    }

    @PatchMapping("/{taskId}/priority")
    public void updatePriority(@PathVariable Long taskId, @RequestParam TaskPriority priority) {
        taskService.updateTaskPriority(taskId, priority);
    }

    @GetMapping("/priority/{priority}")
    public List<TaskDto> getTasksByPriority(@PathVariable TaskPriority priority) {
        return taskService.getTasksByPriority(priority);
    }

    @PostMapping("/{taskId}/comments")
    public void addComment(@PathVariable Long taskId, @RequestBody String comment) {
        taskService.addComment(taskId, comment);
    }

    @GetMapping("/{taskId}")
    public TaskDto getTaskDetails(@PathVariable Long taskId) {
        return taskService.getTaskDetails(taskId);
    }
}
