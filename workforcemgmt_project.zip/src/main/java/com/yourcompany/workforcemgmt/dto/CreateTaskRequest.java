package com.yourcompany.workforcemgmt.dto;

import com.yourcompany.workforcemgmt.model.TaskPriority;
import lombok.Data;

@Data
public class CreateTaskRequest {
    private String title;
    private Long assigneeId;
    private TaskPriority priority;
}
